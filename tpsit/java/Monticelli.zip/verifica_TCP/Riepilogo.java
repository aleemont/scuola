public class Riepilogo{
	double importo;
	String dataora;
	String citta_IN;
	String citta_OUT;
	public Riepilogo(double importo, String dataora, String citta_IN, String citta_OUT)
	{
		this.importo = importo;
		this.dataora = dataora;
		this.citta_IN = citta_IN;
		this.citta_OUT = citta_OUT;
	}
}
